extern "C" void hxcpp_main();

int main(int argc, char *argv[]) {
	hxcpp_main();
	return 0;
}
