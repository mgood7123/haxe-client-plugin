to build:
	
	haxe Build.hx --run Build <args>



	haxe Build.hx --run Build --platform android --NDK "C:\Users\small\AppData\Local\Android\Sdk\ndk\21.4.7075529"

