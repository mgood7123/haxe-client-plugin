to build:
	
	haxe -p android_daw_sdk/src Build.hx --run Build --help
	
	haxe -p android_daw_sdk/src Build.hx --run Build --platform android --NDK "C:/Users/small/AppData/Local/Android/Sdk/ndk/21.4.7075529"
