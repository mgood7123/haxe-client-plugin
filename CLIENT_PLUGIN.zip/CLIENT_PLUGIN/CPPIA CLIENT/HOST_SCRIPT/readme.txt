to build:

  haxe Build.hx --run Build <args>
