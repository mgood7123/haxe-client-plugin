package ::APP_PACKAGE::;

// TEMPLATE

import android.os.Bundle;

public class MainActivity extends org.haxe.lime.GameActivity {
}

